var panel = new Panel
var panelScreen = panel.screen
var freeEdges = {"bottom": true, "top": true, "left": true, "right": true}

for (i = 0; i < panelIds.length; ++i) {
    var tmpPanel = panelById(panelIds[i])
    if (tmpPanel.screen == panelScreen) {
        // Ignore the new panel
        if (tmpPanel.id != panel.id) {
            freeEdges[tmpPanel.location] = false;
        }
    }
}

if (freeEdges["bottom"] == true) {
    panel.location = "bottom";
} else if (freeEdges["top"] == true) {
    panel.location = "top";
} else if (freeEdges["left"] == true) {
    panel.location = "left";
} else if (freeEdges["right"] == true) {
    panel.location = "right";
} else {
    // There is no free edge, so leave the default value
    panel.location = "bottom";
}

// 強制最底
panel.location = "bottom";

// For an Icons-Only Task Manager on the bottom, *3 is too much, *2 is too little
// Round down to next highest even number since the Panel size widget only displays
// even numbers
panel.height = 2 * Math.floor(gridUnit * 2.5 / 2)

// Restrict horizontal panel to a maximum size of a 21:9 monitor
const maximumAspectRatio = 21/9;
if (panel.formFactor === "horizontal") {
    const geo = screenGeometry(panelScreen);
    const maximumWidth = Math.ceil(geo.height * maximumAspectRatio);

    if (geo.width > maximumWidth) {
        panel.alignment = "center";
        panel.minimumLength = maximumWidth;
        panel.maximumLength = maximumWidth;
    }
}

// ------------------------------

// panel.screen.writeConfig("Image", "file:///mnt/microsd/fat32/Pictures/wallpaper/兔子乾杯/S__3334240.jpg")

// ------------------------------

var kickdash = panel.addWidget("org.kde.plasma.kickerdash")
kickdash.currentConfigGroup = ["Shortcuts"]
kickdash.writeConfig("global", "Alt+F1")
kickdash.currentConfigGroup = ["Configuration/General"]
kickdash.writeConfig("showAppsByName", "true")

//panel.addWidget("org.kde.plasma.showActivityManager")
//panel.addWidget("org.kde.plasma.pager")

// ----------------------------

var task = panel.addWidget("org.kde.plasma.taskmanager")
task.writeConfig("groupingStrategy", "0")
task.writeConfig("indicateAudioStreams", "false")
task.writeConfig("launchers", "")
task.writeConfig("maxStripes", "1")
task.writeConfig("middleClickAction", "Close")
task.writeConfig("showOnlyCurrentScreen", "true")
task.writeConfig("showToolTips", "false")
task.writeConfig("wheelEnabled", "false")
//panel.addWidget("org.kde.plasma.marginsseparator")

/* Next up is determining whether to add the Input Method Panel
 * widget to the panel or not. This is done based on whether
 * the system locale's language id is a member of the following
 * white list of languages which are known to pull in one of
 * our supported IME backends when chosen during installation
 * of common distributions. */

var langIds = ["as",    // Assamese
               "bn",    // Bengali
               "bo",    // Tibetan
               "brx",   // Bodo
               "doi",   // Dogri
               "gu",    // Gujarati
               "hi",    // Hindi
               "ja",    // Japanese
               "kn",    // Kannada
               "ko",    // Korean
               "kok",   // Konkani
               "ks",    // Kashmiri
               "lep",   // Lepcha
               "mai",   // Maithili
               "ml",    // Malayalam
               "mni",   // Manipuri
               "mr",    // Marathi
               "ne",    // Nepali
               "or",    // Odia
               "pa",    // Punjabi
               "sa",    // Sanskrit
               "sat",   // Santali
               "sd",    // Sindhi
               "si",    // Sinhala
               "ta",    // Tamil
               "te",    // Telugu
               "th",    // Thai
               "ur",    // Urdu
               "vi",    // Vietnamese
               "zh_CN", // Simplified Chinese
               "zh_TW"] // Traditional Chinese

if (langIds.indexOf(languageId) != -1) {
    panel.addWidget("org.kde.plasma.kimpanel");
}


// ----------------------------

var tray = panel.addWidget("org.kde.plasma.systemtray")
// tray.writeConfig("extraItems", "org.kde.plasma.vault,org.kde.plasma.battery,org.kde.plasma.nightcolorcontrol,org.kde.plasma.printmanager,org.kde.plasma.clipboard,org.kde.kupapplet,org.kde.plasma.networkmanagement,org.kde.plasma.devicenotifier,org.kde.plasma.volume,org.kde.plasma.notifications,org.kde.plasma.mediacontroller,org.kde.plasma.keyboardindicator,org.kde.kdeconnect,org.kde.plasma.keyboardlayout,org.kde.plasma.bluetooth,org.kde.plasma.manage-inputmethod")
// tray.writeConfig("extraItems", "Barrier,flameshot,org.kde.plasma.mediacontroller,org.kde.plasma.notifications,Discover Notifier_org.kde.DiscoverNotifier,org.kde.plasma.bluetooth,org.kde.plasma.battery,org.kde.plasma.devicenotifier,Qsync")
// tray.writeConfig("knownItems", "org.kde.plasma.vault,org.kde.plasma.battery,org.kde.plasma.nightcolorcontrol,org.kde.plasma.printmanager,org.kde.plasma.clipboard,org.kde.kupapplet,org.kde.plasma.networkmanagement,org.kde.plasma.devicenotifier,org.kde.plasma.volume,org.kde.plasma.notifications,org.kde.plasma.mediacontroller,org.kde.plasma.bluetooth,org.kde.plasma.keyboardindicator,org.kde.kdeconnect,org.kde.plasma.keyboardlayout,org.kde.plasma.manage-inputmethod")
// tray.writeConfig("shownItems", "org.kde.plasma.networkmanagement")

// tray.writeConfig("extraItems", "org.kde.plasma.vault,org.kde.plasma.battery,org.kde.plasma.nightcolorcontrol,org.kde.plasma.printmanager,org.kde.plasma.clipboard,org.kde.kupapplet,org.kde.plasma.networkmanagement,org.kde.plasma.devicenotifier,org.kde.plasma.volume,org.kde.plasma.notifications,org.kde.plasma.mediacontroller,org.kde.plasma.bluetooth,org.kde.plasma.keyboardindicator,org.kde.kdeconnect,org.kde.plasma.keyboardlayout,org.kde.plasma.manage-inputmethod")
// tray.writeConfig("extraItems", "org.kde.plasma.networkmanagement,org.kde.plasma.bluetooth,org.kde.plasma.devicenotifier,Qsync")
// tray.writeConfig("hiddenItems", "org.kde.plasma.networkmanagement,org.kde.plasma.bluetooth,org.kde.plasma.devicenotifier,Qsync")
// tray.writeConfig("knownItems", "org.kde.plasma.vault,org.kde.plasma.battery,org.kde.plasma.nightcolorcontrol,org.kde.plasma.printmanager,org.kde.plasma.clipboard,org.kde.kupapplet,org.kde.plasma.networkmanagement,org.kde.plasma.devicenotifier,org.kde.plasma.volume,org.kde.plasma.notifications,org.kde.plasma.mediacontroller,org.kde.plasma.bluetooth,org.kde.plasma.keyboardindicator,org.kde.kdeconnect,org.kde.plasma.keyboardlayout,org.kde.plasma.manage-inputmethod")
// tray.writeConfig("shownItems", "org.kde.plasma.networkmanagement")

// 如何確認自己要隱藏的Item呢？
// /home/pudding/.config/plasma-org.kde.plasma.desktop-appletsrc
// 要加到knownItem跟hiddenItems

var systrayContainmentId = tray.readConfig("SystrayContainmentId")
var systrayContainment = desktopById(systrayContainmentId)
systrayContainment.currentConfigGroup = ["General"]
systrayContainment.writeConfig("knownItems", "Nextcloud,Qsync,Barrier,Crow Translate,flameshot,org.kde.plasma.mediacontroller,org.kde.plasma.notifications,Discover Notifier_org.kde.DiscoverNotifier,org.kde.plasma.bluetooth,org.kde.plasma.networkmanagement,org.kde.plasma.devicenotifier,org.kde.plasma.vault,org.kde.plasma.battery,org.kde.plasma.nightcolorcontrol,org.kde.plasma.printmanager,org.kde.plasma.clipboard,org.kde.kupapplet,org.kde.plasma.volume,org.kde.plasma.manage-inputmethod,org.kde.plasma.keyboardindicator,org.kde.kdeconnect,org.kde.plasma.keyboardlayout,ownCloud,Nextcloud,KDE Daemon")
systrayContainment.writeConfig("hiddenItems", "Nextcloud,Barrier,Crow Translate,flameshot,org.kde.plasma.mediacontroller,org.kde.plasma.notifications,Discover Notifier_org.kde.DiscoverNotifier,org.kde.plasma.bluetooth,org.kde.plasma.networkmanagement,org.kde.plasma.devicenotifier,Qsync,remmina-icon,org.kde.kdeconnect,ownCloud,Nextcloud,KDE Daemon")
systrayContainment.writeConfig("shownItems", "org.kde.plasma.clipboard,org.kde.plasma.manage-inputmethod,org.kde.plasma.battery")

// ----------------------------

var pager = panel.addWidget("org.kde.plasma.pager")
pager.writeConfig("showOnlyCurrentScreen", "true")
pager.writeConfig("showWindowIcons", "true")
pager.writeConfig("wrapPage", "true")

// ----------------------------

var calendar = panel.addWidget("org.kde.plasma.eventcalendar")
calendar.writeConfig("clockShowLine2", "true")
calendar.writeConfig("clockTimeFormat1", "hh:mm")
calendar.writeConfig("clockTimeFormat2", "MM/dd ddd")
// calendar.writeConfig("v71Migration", "true")
// calendar.writeConfig("v72Migration", "true")
// calendar.writeConfig("clockShowLine2", "true")
// clockShowLine2=true
// clockTimeFormat1=hh:mm
// clockTimeFormat2=MM/dd ddd
// v71Migration=true
// v72Migration=true

// panel.addWidget("org.kde.plasma.minimizeall")

var exquisite = panel.addWidget("toggle-exquisite")
